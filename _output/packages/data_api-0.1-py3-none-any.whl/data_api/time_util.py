#!/usr/bin/env python
# coding: utf-8
# create: 2018-07-11
# author: lanqiang@kavout.com

#import time
from datetime import datetime

class TimeUtilError(Exception):
    pass

class TimeUtil():
    def __init__(self, utc_offset=None):
        self.utc_offset = utc_offset

    @staticmethod
    def get_now_datestr(format_str="%Y-%m-%d"):
        return datetime.now().strftime(format_str)

    @staticmethod
    def pre_datestr(datestr):
        return TimeUtil.get_datestr_offset(datestr, -1)

    @staticmethod
    def next_datestr(datestr):
        return TimeUtil.get_datestr_offset(datestr, 1)

    @staticmethod
    def format_datestr(datestr, format_str="%Y-%m-%d"):
        date_time = TimeUtil.convert_timestr_datetime(datestr)
        return date_time.strftime(format_str)

    @staticmethod
    def get_datestr_offset(datestr, delta_day, format_str="%Y-%m-%d"):
        return TimeUtil.get_timestr_offset(datestr, "days", delta_day, format_str)

    @staticmethod
    def split_datestr(datestr):
        date = datestr.replace('-', '').replace('/', '')[:8]
        return int(date[:4]), int(date[4:6]), int(date[6:])

    @staticmethod
    def get_year_month(datestr, separator=True):
        date = datestr.replace('-', '').replace('/', '')[:8]
        formatstr = "%s-%02d" if separator else "%s%02d"
        return formatstr % (date[:4], int(date[4:6]))

    @staticmethod
    def pre_month_datestr_raw(datestr, no_day=False):
        date = datestr.replace('-', '').replace('/', '')[:8]
        year, month = int(date[:4]), int(date[4:6])
        if no_day is False:
            day = int(date[6:])
        month = month-1 if month > 1 else 12
        year = year-1 if month == 12 else year
        if no_day:
            return "%s-%02d" % (year, month)
        return "%s-%02d-%02d" % (year, month, day)

    @staticmethod
    def next_month_datestr_raw(datestr, no_day=False):
        date = datestr.replace('-', '').replace('/', '')[:8]
        year, month = int(date[:4]), int(date[4:6])
        if no_day is False:
            day = int(date[6:])
        month = month+1 if month < 12 else 1
        year = year+1 if month == 1 else year
        if no_day:
            return "%s-%02d" % (year, month)
        return "%s-%02d-%02d" % (year, month, day)

    @staticmethod
    def get_now_timestr(format_str="%Y-%m-%d %H:%M:%S"):
        return datetime.now().strftime(format_str)

    @staticmethod
    def get_weekday_from_timestr(timestr):
        date_time = TimeUtil.convert_timestr_datetime(timestr)
        if not date_time:
            return None
        return date_time.weekday()

    @staticmethod
    def _normalize_timestr(timestr):
        timestr = str(timestr).strip().replace('/', '')
        if len(timestr) < 8:
            return None
        if timestr[4] != '-':
            timestr = timestr[:4] + '-'+ timestr[4:6] + '-' + timestr[6:]
        if len(timestr) > 19:
            return None
        if len(timestr) == 10:
            return timestr + " 00:00:00"
        if len(timestr) == 13:
            return timestr + ":00:00"
        if len(timestr) == 16:
            return timestr + ":00"
        return timestr

    @staticmethod
    def normalize_timestr_format(timestr, format_str="%Y-%m-%d %H:%M:%S"):
        date_time = TimeUtil.convert_timestr_datetime(timestr)
        if not date_time:
            return None
        return date_time.strftime(format_str)

    @staticmethod
    def convert_timestr_datetime(timestr):
        timestr = TimeUtil._normalize_timestr(timestr)
        if not timestr:
            return None
        try:
            return datetime.strptime(timestr, "%Y-%m-%d %H:%M:%S")
        except:
            return None

    @staticmethod
    def convert_datetime_timestr(date_time, format_str="%Y-%m-%d %H:%M:%S"):
        if not isinstance(date_time, datetime):
            return None
        return date_time.strftime(format_str)

    @staticmethod
    def convert_timestr_timestamp(timestr):
        date_time = TimeUtil.convert_timestr_datetime(timestr)
        if not date_time:
            return None
        return int(date_time.timestamp())

    @staticmethod
    def convert_timestamp_timestr(timestamp, format_str="%Y-%m-%d %H:%M:%S"):
        date_time = TimeUtil.convert_timestamp_datetime(timestamp)
        if not date_time:
            return None
        return date_time.strftime(format_str)

    @staticmethod
    def convert_timestamp_datetime(timestamp):
        if isinstance(timestamp, (int, float, str)):
            return datetime.fromtimestamp(int(timestamp))
        return None

    @staticmethod
    def convert_datetime_timestamp(date_time):
        if isinstance(date_time, datetime):
            return int(date_time.timestamp())
        return None

def _test_get_timestr_offset():
    timestr = " 20180102 11:22 "
    timestr = " 2018/01/03 12:35 "
    print(TimeUtil.get_timestr_offset(timestr, "hours", 15))
    print(TimeUtil.get_timestr_offset(timestr, "seconds", -1))
    print(TimeUtil.get_timestr_offset(timestr, "weeks", 1))
    print(TimeUtil.get_timestr_offset(timestr, "days", -3))

def _test_convert_timestamp_datetime():
    timestamp = "1500000000"
    timestamp = 1500000001
    print(TimeUtil.convert_timestamp_datetime(timestamp))

def _test_convert_datetime_timestamp():
    date_time = datetime(2018, 7, 14, 11, 23, 59)
    print(TimeUtil.convert_datetime_timestamp(date_time))

def _test_convert_timestr_datetime():
    timestr = " 20180223 08:35 "
    print(TimeUtil.convert_timestr_datetime(timestr))

def _test_convert_datetime_timestr():
    date_time = datetime(1985, 2, 28, 1, 5, 36)
    print(date_time)
    print(TimeUtil.convert_datetime_timestr(date_time))

def _test_convert_timestr_timestamp():
    timestr = "2018-02-15 12:23:11  "
    print(TimeUtil.convert_timestr_timestamp(timestr))

def _test_convert_timestamp_timestr():
    stamp = "1500000000"
    print(TimeUtil.convert_timestamp_timestr(stamp))

def _test_normalize_timestr_format():
    timestr = " 2018/01/13 11:29  "
    timestr = "2018-01-13 11"
    timestr = "  19780102 11:22:33   "
    print(TimeUtil.normalize_timestr_format(timestr))

def _test_normalize_timestr():
    timestr = "   20180102 23:11    "
    timestr = " 2018/01/02 12:11:00 "
    timestr = " 2018-01-03 11 "
    print(TimeUtil._normalize_timestr(timestr))

def _test_get_now_timestr():
    print(TimeUtil.get_now_timestr("%Y%m"))
    print(TimeUtil.get_now_timestr("%Y%m%d"))
    print(TimeUtil.get_now_timestr("%Y-%m-%d"))
    print(TimeUtil.get_now_timestr("%Y%m%d %H:%M:%S"))
    print(TimeUtil.get_now_timestr("%Y-%m-%d %H:%M:%S"))

def _test_datestr():
    #print(TimeUtil.get_now_datestr())
    date1 = "2019-01-01"
    date2 = "2019/12/30"
    date3 = "20191201"
    print(TimeUtil.pre_datestr(date1))
    print(TimeUtil.next_datestr(date2))
    print(TimeUtil.pre_datestr(date3))

if __name__ == "__main__":
#    _test_get_now_timestr()
#    _test_normalize_timestr()
#    _test_normalize_timestr_format()
#    _test_convert_timestr_datetime()
#    _test_convert_datetime_timestr()
#    _test_convert_timestr_timestamp()
#    _test_convert_timestamp_timestr()
#    _test_convert_timestamp_datetime()
#    _test_convert_datetime_timestamp()
#    _test_get_timestr_offset()
    _test_datestr()
