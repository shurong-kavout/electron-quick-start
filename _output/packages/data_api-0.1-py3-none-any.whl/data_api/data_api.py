# coding: utf-8
# create: 2020-01-20
# author: lanqiang@kavout.com
from __future__ import absolute_import
import json
import traceback
#import requests
import numpy as np
import pandas as pd

#from requests.packages.urllib3.exceptions import InsecureRequestWarning
#requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from js import fetch
from .time_util import TimeUtil
from .settings import US_URL, CN_URL, CN2_URL
from .settings import FUNDAMENTAL_FACTORS
from .settings import TECHNICAL_FACTORS

class DataAPI():
    def __init__(self, region, token):
        if region in ('CN', 'CN2'):
            self.api_url = CN_URL if region == 'CN' else CN2_URL
            self.region = 'cn'
        elif region in ('US', 'USA'):
            self.api_url = US_URL
            self.region = region.lower()
        else:
            assert False, "region %s invalid" % region
        self.token = token

    @staticmethod
    def _concat_pandas(data_list):
        return None if not data_list else pd.concat(data_list, ignore_index=True)

    async def _get_raw_data(self, url, params=None):
        if not params:
            params = {}
        params['token'] = self.token
        for _ in range(3):
            try:
                if params:
                    for key, val in params.items():
                        url += f'&{key}={val}'
                res = await fetch(url, {'referrerPolicy':'unsafe-url'})
                if res.status != 200:
                    print("Warning: Fetch url %s status code %s error!" % (url, res.status_code))
                    continue
                text = await res.text()
                data = json.loads(text)
                if data:
                    df = pd.DataFrame(data)
                    return df
                return pd.DataFrame()
            except BaseException:
                print(traceback.format_exc())
                print("Error: Fetch url %s exception!" % url)
        return None

    def _gen_url_prefix(self, asset='stock', table=None, size=None):
        size = 100 if not size else size
        return self.api_url.format(region=self.region, asset=asset, table=table, size=size)

    async def _get_symbol_data_by_trade_date(self, symbol,
                                       asset='stock', table=None,
                                       start_date=None, end_date=None,
                                       fields=None, size=None, start=None):
        assert table is not None
        if (start_date or end_date) and not size:
            size = 10000
        url = self._gen_url_prefix(asset=asset, table=table, size=size)
        url += "&symbol__eq=%s" % symbol
        if start_date:
            url += "&date__gte=%s" % start_date if asset == 'fund' else "&trade_date__gte=%s" % start_date
        end_date = TimeUtil.get_now_timestr("%Y%m%d") if not end_date else end_date
        url += "&date__lte=%s" % end_date if asset == 'fund' else "&trade_date__lte=%s" % end_date
        if start:
            url += "&start=%s" % start
        if fields:
            url += "&fields=%s" % ','.join(fields)
        #print(url)
        return await self._get_raw_data(url)

    def get_data_by_symbol(self, symbol, asset='stock', table=None,
                           start_date=None, end_date=None,
                           fields=None, size=None, start=None):
        assert fields is None or isinstance(fields, list)
        return self._get_symbol_data_by_trade_date(symbol=symbol,
                                                   table=table,
                                                   asset=asset,
                                                   start_date=start_date,
                                                   end_date=end_date,
                                                   fields=fields,
                                                   size=size,
                                                   start=start)

    async def get_data_by_date(self, trade_date, asset='stock', table=None, fields=None):
        assert table is not None
        assert fields is None or isinstance(fields, list)
        url = self._gen_url_prefix(asset=asset, table=table, size=10000)
        url += "&trade_date__eq=%s" % trade_date
        if fields:
            url += "&fields=%s" % ','.join(fields)
        #print(url)
        return await self._get_raw_data(url)

    async def get_trade_calendar(self, start_date=None, end_date=None):
        url = self._gen_url_prefix(table='trade_calendar', size=10000)
        if start_date:
            url += "&trade_date__gte=%s" % start_date
        end_date = TimeUtil.get_now_timestr("%Y%m%d") if not end_date else end_date
        url += "&trade_date__lte=%s" % end_date
        return await self._get_raw_data(url)

    async def get_latest_trade_dates(self, end_date=None, size=1):
        url = self._gen_url_prefix(table='trade_calendar', size=size)
        end_date = TimeUtil.get_now_timestr("%Y%m%d") if not end_date else end_date
        url += "&trade_date__lte=%s&trade_date__order=-1" % end_date
        data = await self._get_raw_data(url)
        if data is None or data.empty:
            return None
        return list(data['trade_date'].values)

    def get_pre_trade_date(self, date, include=False):
        start_date = TimeUtil.pre_month_datestr_raw(date)
        dates = self.get_trade_calendar(start_date, date)
        if include:
            return dates.iloc[-1][0]
        if dates.iloc[-1][0] == date:
            return dates.iloc[-2][0]
        return dates.iloc[-1][0]

    def get_next_trade_date(self, date, include=False):
        end_date = TimeUtil.next_month_datestr_raw(date)
        dates = self.get_trade_calendar(date, end_date)
        if include:
            return dates.iloc[0][0]
        if dates.iloc[0][0] == date:
            return dates.iloc[1][0]
        return dates.iloc[0][0]

    def is_trade_date(self, date):
        trade_date = self.get_pre_trade_date(date, include=True)
        return trade_date == date

    async def _get_topn_component(self, n, date):
        trade_date = self.get_pre_trade_date(date, include=True)
        url = self._gen_url_prefix(asset="stock", table="daily_price", size=n)
        url += "&trade_date__eq=%s" % trade_date
        url += "&fields=symbol,trade_date,market_cap"
        url += "&market_cap__order=-1"
        data = await self._get_raw_data(url)
        return list(data['symbol'].values)

    async def get_index_component(self, index_symbol, date=None):
        date = TimeUtil.get_now_timestr("%Y-%m-%d") if not date else TimeUtil.format_datestr(date)
        if index_symbol.startswith("TOP"):
            return self._get_topn_component(int(index_symbol[3:]), date)

        url = self._gen_url_prefix(asset="index", table="component_stock", size=10000)
        url += "&symbol__eq=%s" % index_symbol
        fields = ["stock_symbol", "reject_date"]
        url += "&fields=%s" % ','.join(fields)
        url += "&select_date__lte=%s" % date
        symbols = set()
        df = await self._get_raw_data(url)
        for _, row in df.iterrows():
            if not row["reject_date"]:
                symbols.add(row["stock_symbol"])
            elif str(row["reject_date"])[:10] > date:
                symbols.add(row["stock_symbol"])
        return list(symbols)

    async def get_index_component_history(self, index_symbol, start_date):
        start_date = TimeUtil.format_datestr(start_date)
        url = self._gen_url_prefix(asset="index", table="component_stock", size=10000)
        url += "&symbol__eq=%s" % index_symbol
        fields = ["stock_symbol", "reject_date"]
        url += "&fields=%s" % ','.join(fields)
        symbols = set()
        df = await self._get_raw_data(url)
        for _, row in df.iterrows():
            if not row["reject_date"]:
                symbols.add(row["stock_symbol"])
            elif str(row["reject_date"])[:10] > start_date:
                symbols.add(row["stock_symbol"])
        return list(symbols)

    async def get_etf_component_by_date(self, etf_symbol, date):
        url = self._gen_url_prefix(asset="etf", table="component_stock", size=10000)
        url += "&symbol__eq=%s" % etf_symbol
        url += "&trade_date__eq=%s" % date
        fields = ["stock_symbol", "stock_name", "holding_allocation"]
        url += "&fields=%s" % ','.join(fields)
        return await self._get_raw_data(url)

    def get_etf_component(self, etf_symbol, date=None):
        if date:
            return self.get_etf_component_by_date(etf_symbol, date)
        trade_dates = self.get_latest_trade_dates(size=3)
        for cur_date in trade_dates:
            data = self.get_etf_component_by_date(etf_symbol, cur_date)
            if data is not None and not data.empty:
                return data
        return None

    async def get_symbol_etf_list(self, symbol, date=None):
        if not date:
            trade_dates = self.get_latest_trade_dates(size=3)
            date = trade_dates[-1]
        else:
            date = self.get_latest_trade_dates(end_date=date, size=1)[0]
        url = self._gen_url_prefix(asset="etf", table="component_stock", size=10000)
        url += "&trade_date__eq=%s" % date
        url += "&stock_symbol__eq=%s" % symbol
        fields = ["symbol", "holding_allocation"]
        url += "&fields=%s" % ','.join(fields)
        return await self._get_raw_data(url)

    async def get_basic_info_by_symbol(self, symbol, fields=None):
        assert fields is None or isinstance(fields, list)
        url = self._gen_url_prefix(table='basic_info', size=10)
        url += "&symbol__eq=%s" % symbol
        if fields:
            url += "&fields=%s" % ','.join(fields)
        return await self._get_raw_data(url)

    def get_basic_info_by_symbols(self, symbols, fields=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_basic_info_by_symbol(symbol, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    async def get_etf_basic_info_by_symbol(self, symbol, fields=None):
        assert fields is None or isinstance(fields, list)
        url = self._gen_url_prefix(asset='etf', table='basic_info', size=10)
        url += "&symbol__eq=%s" % symbol
        if fields:
            url += "&fields=%s" % ','.join(fields)
        return await self._get_raw_data(url)

    def get_etf_basic_info_by_symbols(self, symbols, fields=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_etf_basic_info_by_symbol(symbol, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    async def get_all_basic_info(self, fields=None, listing_status='listing'):
        status = listing_status.lower()
        assert status in ('listing', 'delisting', 'all')
        assert fields is None or isinstance(fields, list)
        url = self._gen_url_prefix(table='basic_info', size=10000)
        if self.region == "usa":
            url += "&exchange__in=nas,nys"
        if fields:
            url += "&fields=%s" % ','.join(fields)
        if status == 'listing':
            url += "&status__eq=1"
        elif status == 'delisting':
            url += "&status__eq=0"
        data = await self._get_raw_data(url)
        start = 10000
        while True:
            if data is None or data.empty or len(data) % 10000:
                break
            s_url = url + "&start=%s" % start
            s_data = self._get_raw_data(s_url)
            if s_data is None or s_data.empty:
                break
            data = pd.concat([data, s_data], ignore_index=True)
            start += 10000
        return data

    async def get_all_etf_basic_info(self, fields=None, listing_status='listing'):
        status = listing_status.lower()
        assert status in ('listing', 'delisting', 'all')
        assert fields is None or isinstance(fields, list)
        url = self._gen_url_prefix(asset='etf', table='basic_info', size=10000)
        if self.region == "usa":
            url += "&exchange__in=nas,nys"
        if fields:
            url += "&fields=%s" % ','.join(fields)
        if status == 'listing':
            url += "&status__eq=1"
        elif status == 'delisting':
            url += "&status__eq=0"
        data = await self._get_raw_data(url)
        start = 10000
        while True:
            if data is None or data.empty or len(data) % 10000:
                break
            s_url = url + "&start=%s" % start
            s_data = self._get_raw_data(s_url)
            if s_data is None or s_data.empty:
                break
            data = pd.concat([data, s_data], ignore_index=True)
            start += 10000
        return data

    def get_fundamental_factors_by_date(self, trade_date, factors):
        table = "fundamental_indicator"
        fields = ['symbol', 'trade_date']
        for factor in factors:
            if factor in FUNDAMENTAL_FACTORS:
                fields.append(factor)
        if len(fields) <= 2:
            return None
        return self.get_data_by_date(trade_date, table=table, fields=fields)

    def get_technical_factors_by_date(self, trade_date, factors):
        table = "daily_technical_indicator"
        fields = ['symbol', 'trade_date']
        for factor in factors:
            if factor in TECHNICAL_FACTORS:
                fields.append(factor)
        if len(fields) <= 2:
            return None
        return self.get_data_by_date(trade_date, table=table, fields=fields)

    def get_factors_by_date(self, trade_date, factors):
        tech_data = self.get_technical_factors_by_date(trade_date, factors)
        fun_data = self.get_fundamental_factors_by_date(trade_date, factors)
        if tech_data is not None and not tech_data.empty:
            tech_data = tech_data.set_index('symbol')
        if fun_data is not None and not fun_data.empty:
            fun_data = fun_data.set_index('symbol')
        if tech_data is None or tech_data.empty:
            return fun_data
        elif fun_data is None or fun_data.empty:
            return tech_data
        fun_data = fun_data.drop(['trade_date'], axis=1)
        return pd.merge(tech_data, fun_data, left_index=True, right_index=True, how='left')

    def get_factors_by_dates(self, trade_dates, factors):
        assert isinstance(trade_dates, list) and trade_dates
        data_list = []
        for trade_date in trade_dates:
            data = self.get_factors_by_date(trade_date, factors)
            if data is not None:
                data_list.append(data.reset_index())
        return self._concat_pandas(data_list)

    def get_fundamental_factors_by_symbol(self, symbol, factors, start_date=None, end_date=None):
        table = "fundamental_indicator"
        fields = ['symbol', 'trade_date']
        for factor in factors:
            if factor in FUNDAMENTAL_FACTORS:
                fields.append(factor)
        if len(fields) <= 2:
            return None
        data = self.get_data_by_symbol(symbol, table=table, start_date=start_date, end_date=end_date, fields=fields)
        return data

    def get_technical_factors_by_symbol(self, symbol, factors, start_date=None, end_date=None):
        table = "daily_technical_indicator"
        fields = ['symbol', 'trade_date']
        for factor in factors:
            if factor in TECHNICAL_FACTORS:
                fields.append(factor)
        if len(fields) <= 2:
            return None
        data = self.get_data_by_symbol(symbol, table=table, start_date=start_date, end_date=end_date, fields=fields)
        return data

    def get_factors_by_symbol(self, symbol, factors, start_date=None, end_date=None):
        tech_data = self.get_technical_factors_by_symbol(symbol, factors, start_date=start_date, end_date=end_date)
        fun_data = self.get_fundamental_factors_by_symbol(symbol, factors, start_date=start_date, end_date=end_date)
        if tech_data is not None and not tech_data.empty:
            tech_data = tech_data.set_index('trade_date')
        if fun_data is not None and not fun_data.empty:
            fun_data = fun_data.set_index('trade_date')
        if tech_data is None or tech_data.empty:
            return fun_data
        elif fun_data is None or fun_data.empty:
            return tech_data
        fun_data = fun_data.drop(['symbol'], axis=1)
        return pd.merge(tech_data, fun_data, left_index=True, right_index=True, how='left')

    def get_factors_by_symbols(self, symbols, factors, start_date=None, end_date=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_factors_by_symbol(symbol, factors, start_date, end_date)
            if data is not None:
                data_list.append(data.reset_index())
        return self._concat_pandas(data_list)

    def get_quote_by_symbol(self, symbol, fields=None, start_date=None, end_date=None):
        table = "daily_price"
        return self.get_data_by_symbol(symbol, table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_etf_quote_by_symbol(self, symbol, fields=None, start_date=None, end_date=None):
        table = "daily_price"
        return self.get_data_by_symbol(symbol, asset='etf', table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_fund_quote_by_symbol(self, symbol, fields=None, start_date=None, end_date=None):
        table = "daily_price"
        return self.get_data_by_symbol(symbol, asset='fund', table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_index_quote(self, index_symbol, fields=None, start_date=None, end_date=None):
        table = "daily_price"
        return self.get_data_by_symbol(index_symbol, asset='index', table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_quote_by_symbols(self, symbols, fields=None, start_date=None, end_date=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_quote_by_symbol(symbol, fields, start_date, end_date)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_etf_quote_by_symbols(self, symbols, fields=None, start_date=None, end_date=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_etf_quote_by_symbol(symbol, fields, start_date, end_date)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_quote_by_date(self, trade_date, fields=None):
        table = "daily_price"
        return self.get_data_by_date(trade_date, table=table, fields=fields)

    def get_etf_quote_by_date(self, trade_date, fields=None):
        table = "daily_price"
        return self.get_data_by_date(trade_date, asset='etf', table=table, fields=fields)

    def get_quote_by_dates(self, trade_dates, fields=None):
        assert isinstance(trade_dates, list) and trade_dates
        data_list = []
        for trade_date in trade_dates:
            data = self.get_quote_by_date(trade_date, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_etf_quote_by_dates(self, trade_dates, fields=None):
        assert isinstance(trade_dates, list) and trade_dates
        data_list = []
        for trade_date in trade_dates:
            data = self.get_etf_quote_by_date(trade_date, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    @staticmethod
    def _calc_symbol_daily_return(quote):
        assert 'adj_close' in quote.columns or 'close' in quote.columns
        column = 'adj_close' if 'adj_close' in quote.columns else 'close'
        if quote.index.name != 'trade_date':
            quote = quote.set_index('trade_date').sort_index()
        else:
            quote = quote.sort_index()
        quote['daily_return'] = quote[column].pct_change()
        return quote

    @staticmethod
    def get_quote_daily_return(quote):
        if quote is None or quote.empty:
            return None
        if quote.index.name == 'trade_date':
            return DataAPI._calc_symbol_daily_return(quote)
        assert 'symbol' in quote.columns
        quote_list = []
        for _, s_quote in quote.groupby(by='symbol'):
            quote_return = DataAPI._calc_symbol_daily_return(s_quote)
            quote_list.append(quote_return.reset_index())
        return DataAPI._concat_pandas(quote_list)

    @staticmethod
    def _calc_symbol_monthly_return(quote):
        assert 'adj_close' in quote.columns or 'close' in quote.columns
        column = 'adj_close' if 'adj_close' in quote.columns else 'close'
        if quote.index.name != 'trade_date':
            quote = quote.set_index('trade_date').sort_index()
        else:
            quote = quote.sort_index()
        date_list = list(quote.index)
        pre_month_end_date, cur_month_end_date = None, None
        month_end_date_pairs = []
        for i in range(1, len(date_list)):
            if str(date_list[i])[:10][-2:] < str(date_list[i-1])[:10][-2:]:
                cur_month_end_date = date_list[i-1]
                if pre_month_end_date:
                    month_end_date_pairs.append((pre_month_end_date, cur_month_end_date))
                pre_month_end_date = cur_month_end_date
        if pre_month_end_date:
            month_end_date_pairs.append((pre_month_end_date, date_list[-1]))
        #print(month_end_date_pairs)
        for pre_month_end_date, cur_month_end_date in month_end_date_pairs:
            monthly_return = quote.loc[cur_month_end_date][column] / quote.loc[pre_month_end_date][column] - 1
            quote.loc[cur_month_end_date, 'monthly_return'] = monthly_return
        if not month_end_date_pairs:
            quote['monthly_return'] = np.nan
        return quote

    @staticmethod
    def get_quote_monthly_return(quote):
        if quote is None or quote.empty:
            return None
        if quote.index.name == 'trade_date':
            return DataAPI._calc_symbol_monthly_return(quote)
        assert 'symbol' in quote.columns
        quote_list = []
        for _, s_quote in quote.groupby(by='symbol'):
            quote_return = DataAPI._calc_symbol_monthly_return(s_quote)
            quote_list.append(quote_return.reset_index())
        return DataAPI._concat_pandas(quote_list)

    def get_kscore_longshort_by_symbol(self, symbol, fields=None, start_date=None, end_date=None):
        table = "kscore_longshort"
        return self.get_data_by_symbol(symbol, table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_kscore_by_symbol(self, symbol, fields=None, start_date=None, end_date=None):
        table = "kscore"
        return self.get_data_by_symbol(symbol, table=table, start_date=start_date, end_date=end_date, fields=fields)

    def get_kscore_longshort_by_symbols(self, symbols, fields=None, start_date=None, end_date=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_kscore_longshort_by_symbol(symbol, fields, start_date, end_date)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_kscore_by_symbols(self, symbols, fields=None, start_date=None, end_date=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_kscore_by_symbol(symbol, fields, start_date, end_date)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_kscore_longshort_by_date(self, trade_date, fields=None):
        table = "kscore_longshort"
        return self.get_data_by_date(trade_date, table=table, fields=fields)

    def get_kscore_by_date(self, trade_date, fields=None):
        table = "kscore"
        return self.get_data_by_date(trade_date, table=table, fields=fields)

    def get_kscore_longshort_by_dates(self, trade_dates, fields=None):
        assert isinstance(trade_dates, list) and trade_dates
        data_list = []
        for trade_date in trade_dates:
            data = self.get_kscore_longshort_by_date(trade_date, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_kscore_by_dates(self, trade_dates, fields=None):
        assert isinstance(trade_dates, list) and trade_dates
        data_list = []
        for trade_date in trade_dates:
            data = self.get_kscore_by_date(trade_date, fields)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_minute_quote_by_symbol(self, symbol, freq, fields=None, start_time=None, end_time=None, size=None):
        freq = int(freq)
        assert freq >= 1 and freq <= 30
        table = "%sminute_price" % freq
        size = int(size) if size else 2000
        start_time = start_time.replace(' ', '%20') if start_time else None
        end_time = end_time.replace(' ', '%20') if end_time else TimeUtil.get_now_timestr("%Y-%m-%d %H:%M:%S").replace(' ', '%20')
        return self.get_data_by_symbol(symbol, table=table, start_date=start_time, end_date=end_time, size=size, fields=fields)

    def get_minute_quote_by_symbols(self, symbols, freq, fields=None, start_time=None, end_time=None, size=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_minute_quote_by_symbol(symbol, freq, fields, start_time, end_time, size)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    def get_etf_minute_quote_by_symbol(self, symbol, freq, fields=None, start_time=None, end_time=None, size=None):
        freq = int(freq)
        assert freq >= 1 and freq <= 30
        table = "%sminute_price" % freq
        size = int(size) if size else 2000
        start_time = start_time.replace(' ', '%20') if start_time else None
        end_time = end_time.replace(' ', '%20') if end_time else TimeUtil.get_now_timestr("%Y-%m-%d %H:%M:%S").replace(' ', '%20')
        return self.get_data_by_symbol(symbol, asset='etf', table=table, start_date=start_time, end_date=end_time, size=size, fields=fields)

    def get_etf_minute_quote_by_symbols(self, symbols, freq, fields=None, start_time=None, end_time=None, size=None):
        assert isinstance(symbols, list) and symbols
        data_list = []
        for symbol in symbols:
            data = self.get_etf_minute_quote_by_symbol(symbol, freq, fields, start_time, end_time, size)
            if data is not None:
                data_list.append(data)
        return self._concat_pandas(data_list)

    async def get_best_AIMVQ_strategy(self, universe, category, end_date, topn,
                                order='sharpe', kscore_type='kscore', strategy_type='long'):
        assert universe in ('SPX', '000300', 'TOP1500', 'TOP1000')
        for c in category:
            assert c in ('M', 'V', 'Q', 'S')
        assert end_date.endswith("-01")
        assert order in ('sharpe', 'cagr')
        assert kscore_type in ('kscore', 'klongshort', 'kmerge')
        assert strategy_type in ('long', 'short', 'neutral')

        category = ''.join(sorted(category))
        category = kscore_type + "_" + universe + "_" + category
        size = int(topn)
        order_dir = 1 if strategy_type == 'short' else -1
        if strategy_type == 'long':
            quanlite_id = 1
        elif strategy_type == 'short':
            quanlite_id = 2
        else:
            quanlite_id = 0
        table = "kscore_factors_metric"

        url = self._gen_url_prefix(table=table, size=size)
        url += "&category__eq=%s" % category
        url += "&end_date__eq=%s" % end_date
        url += "&%s__order=%s" % (order, order_dir)
        url += "&quanlite_id__eq=%s" % quanlite_id
        url += "&fields=name,cagr,sharpe,max_drawdown"
        return await self._get_raw_data(url)

    async def get_custom_data(self, asset, table, params, size=10000):
        url = self._gen_url_prefix(asset=asset, table=table, size=size)
        return await self._get_raw_data(url, params)


if __name__ == "__main__":
    API = DataAPI(region='USA', token='xxxxxxxxxx')
    fields = ["symbol", "trade_date", "adj_close"]
    data = API.get_quote_by_date("2020-01-16", fields=fields)
    print(data)
    factors = ["trend_price", "ps", "pb", "pe"]
    data = API.get_factors_by_symbol("AAPL", factors, start_date="20180101", end_date="20180408")
    print(data)
